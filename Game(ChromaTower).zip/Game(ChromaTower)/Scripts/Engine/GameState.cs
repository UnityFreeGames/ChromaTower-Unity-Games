﻿namespace RectangleTrainer.ChromaTower.Engine
{
    public enum GameState
    {
        Idle,
        InProgress,
        GameOver
    }
}